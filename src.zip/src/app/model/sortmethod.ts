export class Sortmethod{
    public id: number;
    public sortBy: string;
}