export class Resetpassword {
  newPassword: string;
  confirmPassword: string;
}
