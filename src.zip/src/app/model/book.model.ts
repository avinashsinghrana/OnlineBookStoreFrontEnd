export class Book {
    bookName: string;
    bookId: number;
    userId: number;
    bookCode: string;
    bookDetails: string;
    price: number;
    quantity: number;
    authorName: string;
    bookImgUrl: string;
    seller: string;
  }
  