import {Component, OnInit} from '@angular/core';
import {SellerService} from '../../services/seller.service';
import {MessageService} from '../../services/message.service';
import {MatSnackBar, MatDialog} from '@angular/material';
import {UpdateBookComponent} from '../update-book/update-book.component';
import {Book} from 'src/app/models/book.model';
import {CartServiceService} from 'src/app/services/cart-service/cart-service.service';
import {CartserviceService} from 'src/app/services/cartservice.service';
import {WishlistComponent} from '../wishlist/wishlist.component';
import {WishlistService} from '../wishListservice/wishlist.service';
import {BookserviceService} from '../../services/bookservice/bookservice.service';

@Component({
  selector: 'app-user-books',
  templateUrl: './user-books.component.html',
  styleUrls: ['./user-books.component.scss'],
})
export class UserBooksComponent implements OnInit {
  books = [];
  book: Book[];
  searchTerm: string;
  message: string;
  size: any;
  sortTerm: string;
  add: false;
  wishValue: any = [];
  toggle = true;
  item: any = 0;
  page = 1;
  cartValue: any = [];
  token: string;

  constructor(
    private vendorService: SellerService,
    private messageService: MessageService,
    private snackBar: MatSnackBar,
    private cartServiceService: CartServiceService,
    private cartServices: CartserviceService,
    private data: MessageService,
    private dialog: MatDialog,
    private wishlistService: WishlistService,
    private bookService: BookserviceService
  ) {

  }

  ngOnInit() {
    this.updateStatus();
    this.sortTerm = 'none';
    this.item = sessionStorage.getItem('size');
    this.data.changeItem(this.item);
    this.bookService.getBookList().subscribe(data => {
      this.book = data;
    });
    this.messageService.currentMessages.subscribe((data) => {
      this.books = [];
      this.onDisplayBooks(data);
    });
    this.updateStatus();
    this.messageService.currentEvent$.subscribe(message => {
      this.searchTerm = message;
    });
    //
    // this.sortTerm = 'none';
    // this.messageService.currentMessages.subscribe((data) => {
    //   this.books = [];
    //   this.onDisplayBooks(data);
    // });
    // this.messageService.currentEvent$.subscribe(message => {
    //   this.searchTerm = message;
    // });
  }
  updateStatus(){
    this.wishlistService.getIdFromWishList().subscribe(data => {
      this.cartValue = data;
    });
    this.cartServiceService.getIdFromCartList().subscribe(data => {
      this.wishValue = data;
    });
  }

  onBookDetail(event) {
    event.stopPropagation();
  }

  onKey(event) {
    this.searchTerm = event;
  }

  onSelect(val: any) {
    this.sortTerm = val;
    console.log('sorting term', this.sortTerm);
  }

  onWish(bookId: any) {
    this.wishlistService.addToWishList(bookId, localStorage.getItem('token')).subscribe((data) => {
      console.log(data);
      this.updateStatus();
    });
    this.snackBar.open('Yeah, Added to WishList !!', 'Ok', {duration: 800});
  }

  onDisplayBooks(data) {
    console.log(data);
    if (data.status === 200) {
      this.size = data.data.length;
      data.data.forEach((bookData) => {
        this.books.push(bookData);
      });
    }
  }


  onAddBook(bookId) {
    // ****************************************************************************//
    // tslint:disable-next-line:one-variable-per-declaration
    // const target = event.target,
    //   count = +target.dataset.count;
    // target.style.backgroundColor = count === 1 ? '#7FFF00' : '#FFFFFF';
    // target.dataset.count = count === 1 ? 0 : 1;
    // ****************************************************************************//
    this.toggle = !this.toggle;
    this.item += 1;
    this.token = localStorage.getItem('token');
    this.data.changeItem(this.item);
    this.cartServices.addToBag(bookId, this.token).subscribe((message) => {
      console.log(message);
      this.updateStatus();
      sessionStorage.setItem(bookId, bookId);
      this.data.changeItem(message.data);
      sessionStorage.setItem('size', message.data);
      this.snackBar.open('Book Added to Bag SuccessFully', 'OK', {
        duration: 600,
      });
    });
  }

  valueCheck(i: number, bookId: any) {
    let key = -1;
    for (let i = 0; i <= this.cartValue.length; i++) {
      if (this.cartValue[i] === bookId) {
        key = bookId;
      }
    }
    return key;
  }

  wishCheck(i: number, bookId: any) {
    let key = -1;
    for (let i = 0; i <= this.wishValue.length; i++) {
      if (this.wishValue[i] === bookId) {
        key = bookId;
      }
    }
    return key;
  }
}
