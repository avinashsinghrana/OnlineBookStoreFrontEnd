export interface Login {
    emailId: string;
    password: string;
  }
  