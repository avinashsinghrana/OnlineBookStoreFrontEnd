import {Injectable} from '@angular/core';
import {HttpClient, HttpHeaders, HttpParams} from '@angular/common/http';
import {FormGroup} from '@angular/forms';
import {Observable} from 'rxjs';
import {HttpService} from './../services/http.service';
import {environment} from 'src/environments/environment';

@Injectable({
  providedIn: 'root',
})
export class SellerService {
  private addBookApi = 'sellers/addBook';
  private updateBookApi = '/sellers/updateBook';
  private deleteBookApi = '/sellers/deleteBook';
  private displayBookApi = '/sellers/getUnverifiedBooks';
  private uploadBookProfileApi = 'users/uploadImage';
  private approveBookApi = '/admin/bookVerification';
  private displayAllBookApi = '/admin/getBooksForVerification';
  private getBookApi = '/user/getallBooks';

  constructor(private http: HttpClient, private service: HttpService) {
  }

  addBook(body: any, token: any): Observable<any> {
    return this.service.postBook(body, token);
  }

  /* addBook(book: any): Observable<any> {
     return this.http.post(environment.baseUrl + this.addBookApi, book, {
       headers: new HttpHeaders().set('token', localStorage.getItem('stoken')),
     });
   }*/

  displayBooks(): Observable<any> {
    return this.http.get(environment.baseUrl + this.displayBookApi, {
      headers: new HttpHeaders().set('token', localStorage.getItem('token')),
    });
  }

  getBooks(): Observable<any> {
    var httpOptions = {
      headers: new HttpHeaders({'Content-Type': 'application/json'})
    };
    return this.http.get(environment.baseUrl + this.getBookApi, httpOptions);
  }

  displayAllBooks(): Observable<any> {
    return this.http.get(environment.baseUrl + this.displayAllBookApi, {
      headers: new HttpHeaders().set('token', localStorage.getItem('token')),
    });
  }

  deleteBooks(bookId: any): Observable<any> {
    return this.http.delete(environment.baseUrl + this.deleteBookApi + '/' + bookId, {
      headers: new HttpHeaders().set('token', localStorage.getItem('token')),
    });
  }

  uploadBookImage(file: FormData, isProfile: string): Observable<any> {
    return this.http.post(
      environment.baseUrl + this.uploadBookProfileApi,
      file,
      {
        headers: new HttpHeaders().set('token', localStorage.getItem('token')),
        params: new HttpParams().set('isProfile', isProfile),
      }
    );
  }

  updateBook(body: any, bookId: any): Observable<any> {
    return this.http.put(
      environment.baseUrl + this.updateBookApi + '/' + bookId, body,
      {
        headers: new HttpHeaders().set('token', localStorage.getItem('token')),
      }
    );
  }

  onApprove(bookId: any, sellerId: any): Observable<any> {
    return this.http.put(
      environment.baseUrl + this.approveBookApi + '/' + sellerId + '/' + bookId,
      {
        headers: new HttpHeaders().set('token', localStorage.getItem('token')),
      }
    );
  }

  getAllBooksOfAdmin() {
    return this.http.get('http://localhost:8081/admin/getBooksForVerification?token=' + localStorage.getItem('token'));
  }
}
